public abstract class Person {

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    String ad;

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    String soyad;

    public Person( String ad, String Soyad){

        this.ad= ad;
        this.soyad= soyad;
    }

}
