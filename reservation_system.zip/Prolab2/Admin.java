import java.util.*;

public class Admin extends User {

    public Admin() {
        super();
    }

    public List<String> getFirmalar() {
        if (firmalar == null) {
            firmalar = new ArrayList<>(); // veya tercih ettiğiniz başka bir List uygulaması
        }
        return firmalar;
    }

    public void setFirmalar(List<String> firmalar) {
        this.firmalar = firmalar;
    }

    public Admin(String username, String password, List<String> firmalar) {
        super(username, password);
        this.firmalar = firmalar;
    }

    public List<String> firmalar;


    public Admin(String username, String password) {
        super(username, password);
        this.firmalar = new ArrayList<>();

        firmalar.add("A");
        firmalar.add("B");
        firmalar.add("C");
        firmalar.add("D");
        firmalar.add("F");

        firmaGoster();
    }

    @Override
    public void karHesabi() {
        //
    }

    @Override
    public void ekleme() {

    }

    @Override
    public void cikarma() {

    }

    public void firmaEkleme(String firmaAdi) {
        this.firmalar.add(firmaAdi);
        System.out.println(firmaAdi + " firması eklendi.");
        firmaGoster(); // Yeni firmanın eklenmiş listeyi göster
    }

    public void firmaSilme(String firmaAdi) {
        if (this.firmalar.contains(firmaAdi)) {
            this.firmalar.remove(firmaAdi);
            System.out.println(firmaAdi + " firması silindi.");
            firmaGoster(); // Güncellenmiş listeyi göster
        } else {
            System.out.println(firmaAdi + " firması bulunamadı. Silme işlemi gerçekleştirilemedi.");
        }
    }

    public void firmaGoster() {
        System.out.println("Firmalarımız: ");
        for (String firma : this.firmalar) {
            System.out.println(firma);
        }

    }

}

