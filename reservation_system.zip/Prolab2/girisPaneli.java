import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class girisPaneli extends JFrame {
    private JPanel panel1;
    private JButton adminButton;
    private JButton firmaButton;
    private JButton biletAraButton;

    public girisPaneli() {

        add(panel1);
        setSize(400, 400);
        setTitle(" Giriş Ekranı");

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Kullanıcı butonuna tıklandığında adminGiriş'i görünür yap
                adminGirisi adminButton = new adminGirisi();
                adminButton.setVisible(true);
            }
        });

        firmaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Kullanıcı butonuna tıklandığında firmaGiriş'i görünür yap
                firmaGirisi firmaButton = new firmaGirisi();
                firmaButton.setVisible(true);
            }
        });

        biletAraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Bilet ara butonuna tıklandığında kullanıcısecimpanelin'i görünür yap
                kullanicisecimpaneli biletAraButton = new kullanicisecimpaneli();
                biletAraButton.setVisible(true);
            }
        });

    }

}
