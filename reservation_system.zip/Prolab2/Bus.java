import java.util.*;
public class Bus extends Vehicle{

    public Bus(int vehicleId, String fuelType, int capacity, String companyName, int tripNo, int fuelMileageFee) {
        super(vehicleId, fuelType, capacity, companyName, tripNo, fuelMileageFee);
        seatStatus = new HashMap<>();
        initializeSeatStatus(capacity);
    }

    @Override
    public void calculateFuelCost() {
    }
}