import java.util.HashMap;

public class Train extends Vehicle{

    public Train(int vehicleId, String fuelType, int capacity, String companyName, int tripNo, int fuelMileageFee) {
        super(vehicleId, fuelType, capacity, companyName, tripNo, fuelMileageFee);
        seatStatus = new HashMap<>();
        initializeSeatStatus(capacity);
    }



    @Override
    public void calculateFuelCost() {
    }
}