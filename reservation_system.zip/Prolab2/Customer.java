public class Customer {
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    private String customerName;

    public String getCostumerSurname() {
        return costumerSurname;
    }

    public void setCostumerSurname(String costumerSurname) {
        this.costumerSurname = costumerSurname;
    }

    private String costumerSurname;

    public String getCostumerSex() {
        return costumerSex;
    }

    public void setCostumerSex(String costumerSex) {
        this.costumerSex = costumerSex;
    }

    private String costumerSex;

    public int getCustomerTC() {
        return customerTC;
    }

    public void setCustomerTC(int customerTC) {
        this.customerTC = customerTC;
    }

    private int customerTC;


    //kalkis noktasi secme
    public void selectDeparture() {

    }

    //varis noktasi secme
    public void selectArrival() {

    }

    //tarih secme (1 haftalık tarih gösterilecek 4-10 Aralık)
    public void selectDate() {

    }

    //ulasim araclarinin listesini goruntuleme
    public void getListOfVehicles() {


    }

    //rezervasyon yapma
    public void reservation() {

    }

    //rezervasyon yapılan koltugun rezervasyona kapatılmasi
    public void closedReservation() {

    }


    //yolcu sayısı secilecek
    public void numberOfPassengers() {

    }

    //sefer bul butonu ve uygun seferlerin gosterilmesi
    public void findAvaibleTrip() {

    }

    //bos koltuk sayisi
    public void freeSeats() {

    }

    //firma ve arac secme
    public void selactCompany() {
        //bos ve rezerve koltuk sayisi
    }

    public void selectSeats() {
        //numberOfPassengers yolcu sayisi kadar seçim yapabilir
    }

    //her yolcu icin bilgi girisi olacak Kullanıcı, yolcu adı, soyadı, T.C. numarası, doğum tarihi gibi bilgileri girmelidir.//

    //odeme butonu
    /*Ödeme işlemi başarıyla tamamlandığında, seçilen sefer ve rezervasyon işlemi
    yapılan koltuklar ekranda görüntülenir.
    Rezerve edilen koltuklar, rezervasyon işlemi tamamlandığında görünür.*/

}