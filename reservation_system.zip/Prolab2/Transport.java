import java.util.*;

public class Transport implements IReservable {
    public HashMap<Integer, Boolean> getSeats() {
        return seats;
    }

    public void setSeats(HashMap<Integer, Boolean> seats) {
        this.seats = seats;
    }

    HashMap<Integer, Boolean> seats = new HashMap<>();

    @Override
    public void showAvailableSeats() {
        System.out.print("Available Seats: ");
        for (Map.Entry<Integer, Boolean> entry : seats.entrySet()) {
            if (!entry.getValue()) {
                System.out.print(entry.getKey() + " ");
            }
        }
        System.out.println();
    }

    @Override
    public void selectSeat(int seatNumber) {

    }
}