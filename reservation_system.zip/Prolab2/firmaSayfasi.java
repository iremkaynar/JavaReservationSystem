import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class firmaSayfasi extends JFrame {
    private JPanel panel;
    private Company firma;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JButton seferEkleButton;
    private JButton seferÇıkarButton;
    private JButton araçEkleButton;
    private JButton araçÇıkarButton;
    private JButton bilgileriGösterButton;

    public firmaSayfasi(String username) {
        this.firma = new Company(username, "firmaPassword");
    }

    public firmaSayfasi() {
        this.firma = new Company("", "");
        panel = new JPanel();
        textArea1 = new JTextArea(10, 10);
        textArea2 = new JTextArea(10, 10);
        seferEkleButton = new JButton("Sefer Ekle");
        seferÇıkarButton = new JButton("Sefer Sil");
        araçEkleButton = new JButton("Araç Ekle");
        araçÇıkarButton = new JButton("Araç Sil");
        bilgileriGösterButton = new JButton("Bilgileri Göster");


        // Swing bileşenlerini panoya ekleyin
        panel.add(new JScrollPane(textArea1));
        panel.add(araçEkleButton);
        panel.add(araçÇıkarButton);
        panel.add(new JScrollPane(textArea2));
        panel.add(seferEkleButton);
        panel.add(seferÇıkarButton);
        panel.add(bilgileriGösterButton);


        // Frame'i ayarla
        this.add(panel);
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        // sefer Ekle butonuna tıklanınca bir olay dinleyici ekle
        seferEkleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seferEkleButonuTiklandi();
            }
        });

        // sefer Sil butonuna tıklanınca bir olay dinleyici ekle
        seferÇıkarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                seferÇıkarButonuTiklandi();
            }
        });

        // araç Ekle butonuna tıklanınca bir olay dinleyici ekle
        araçEkleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                araçEkleButonuTiklandi();
            }
        });

        // araç Sil butonuna tıklanınca bir olay dinleyici ekle
        araçÇıkarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                araçÇıkarButonuTiklandi();
            }
        });


        // Add action listener to the new button
        bilgileriGösterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCompanyVehiclesInfo();
            }
        });

    }

    // arac ekle butonu tıklandığında yapılacak işlemler
    private void araçEkleButonuTiklandi() {
        // Araç eklemek için gerekli işlemleri yap
        String yeniAracAdi = JOptionPane.showInputDialog("Yeni Araç Adı:");
        firma.ekleme(yeniAracAdi);

        // Güncellenmiş Araç listesini göster
        guncellenmisAracListesiniGoster();
    }

    // Araç sil butonu tıklandığında yapılacak işlemler
    private void araçÇıkarButonuTiklandi() {
        // Araç silmek için gerekli işlemleri yap
        String silinecekAraçAdi = JOptionPane.showInputDialog("Silinecek Araç Adı:");
        firma.cikarma(silinecekAraçAdi);

        // Güncellenmiş Araç listesini göster
        guncellenmisAracListesiniGoster();
    }

    private void seferEkleButonuTiklandi() {
        // sefer eklemek için gerekli işlemleri yap
        String yeniSeferAdi = JOptionPane.showInputDialog("Yeni Sefer Adı:");
        firma.ekleme(yeniSeferAdi);

        // Güncellenmiş sefer listesini göster
        guncellenmisSeferListesiniGoster();
    }

    // sefer sil butonu tıklandığında yapılacak işlemler
    private void seferÇıkarButonuTiklandi() {
        // sefer silmek için gerekli işlemleri yap
        String silinecekSeferAdi = JOptionPane.showInputDialog("Silinecek Sefer Adı:");
        firma.cikarma(silinecekSeferAdi);

        // Güncellenmiş sefer listesini göster
        guncellenmisSeferListesiniGoster();
    }


    // Güncellenmiş Araç listesini göster
    private void guncellenmisAracListesiniGoster() {

    }


    private void araclariGösterButonuTiklandi() {
        guncellenmisAracListesiniGoster();
    }


    // Güncellenmiş sefer listesini göster
    private void guncellenmisSeferListesiniGoster() {

    }


    private void seferleriGösterButonuTiklandi() {
        guncellenmisSeferListesiniGoster();
    }

    private void bilgileriGösterButonuTiklandi() {
        showCompanyVehiclesInfo();
    }


    public void showCompanyVehiclesInfo() {
        Trip sefer = new Trip();
        StringBuilder info = new StringBuilder();

        if (firma.getUsername().equals("afirma")) {
            info.append("Company A Vehicles:\n");
            info.append("Bus 1:\n")
                    .append("\nFuel Type: ").append(sefer.getBus1CompanyA().getFuelType())
                    .append("\nCapacity: ").append(sefer.getBus1CompanyA().getCapacity());


            info.append("\nBus 2:\n")
                    .append("\nFuel Type: ").append(sefer.getBus2CompanyA().getFuelType())
                    .append("\nCapacity: ").append(sefer.getBus2CompanyA().getCapacity());


            textArea1.setText(info.toString());
        }

        if (firma.getUsername().equals("bfirma")) {
            info.append("Company B Vehicles:\n");
            info.append("Bus 1:\n")
                    .append("\nFuel Type: ").append(sefer.getBus1CompanyB().getFuelType())
                    .append("\nCapacity: ").append(sefer.getBus1CompanyB().getCapacity());


            info.append("\nBus 2:\n")
                    .append("\nFuel Type: ").append(sefer.getBus2CompanyB().getFuelType())
                    .append("\nCapacity: ").append(sefer.getBus2CompanyB().getCapacity());


            textArea1.setText(info.toString());
        }
    }


}
