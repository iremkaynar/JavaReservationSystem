import javax.swing.*;

public class kullanicisecimpaneli extends JFrame{
    private JPanel kalkisvaristarihsecimi;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JCheckBox a05122023CheckBox;
    private JCheckBox a04122023CheckBox;
    private JCheckBox a09122023CheckBox;
    private JCheckBox a10122023CheckBox;
    private JCheckBox a07122023CheckBox;
    private JCheckBox a06122023CheckBox;
    private JCheckBox a08122023CheckBox;
    private JTextField textField1;
    private JButton geriButton;
    private JButton seferGörüntüleButton;


    public kullanicisecimpaneli(){

        textField1 = new JTextField(10);

        kalkisvaristarihsecimi = new JPanel();
        kalkisvaristarihsecimi.add(new JLabel("Kalkış Noktası"));
        kalkisvaristarihsecimi.add(comboBox1);
        kalkisvaristarihsecimi.add(new JLabel("Varış noktası"));
        kalkisvaristarihsecimi.add(comboBox2);

        kalkisvaristarihsecimi.add(new JLabel("Tarih Seçiniz"));
        kalkisvaristarihsecimi.add(a04122023CheckBox);
        kalkisvaristarihsecimi.add(a05122023CheckBox);
        kalkisvaristarihsecimi.add(a06122023CheckBox);
        kalkisvaristarihsecimi.add(a07122023CheckBox);
        kalkisvaristarihsecimi.add(a08122023CheckBox);
        kalkisvaristarihsecimi.add(a09122023CheckBox);
        kalkisvaristarihsecimi.add(a10122023CheckBox);

        kalkisvaristarihsecimi.add(new JLabel("Yolcu Sayısı Giriniz"));
        kalkisvaristarihsecimi.add(textField1);

        kalkisvaristarihsecimi.add(geriButton);
        kalkisvaristarihsecimi.add(seferGörüntüleButton);

        add(kalkisvaristarihsecimi);
        setSize(400, 200);
        setTitle("Seçim Ekranı");

}
}

