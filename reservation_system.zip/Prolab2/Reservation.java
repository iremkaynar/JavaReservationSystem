public class Reservation {

    public int getYolcu() {
        return yolcu;
    }

    public void setYolcu(int yolcu) {
        this.yolcu = yolcu;
    }

    // yolcu, araç, koltuk bilgisi
    int yolcu;

    public String getArac() {
        return arac;
    }

    public void setArac(String arac) {
        this.arac = arac;
    }

    String arac;

    public int getKoltuk() {
        return koltuk;
    }

    public void setKoltuk(int koltuk) {
        this.koltuk = koltuk;
    }

    int koltuk;

}
