public interface IProfitable {
    void karHesabi();
}
