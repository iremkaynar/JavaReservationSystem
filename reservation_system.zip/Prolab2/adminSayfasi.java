import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class adminSayfasi extends JFrame {

    private JPanel panel1;
    private JButton firmaEkleButton;
    private JButton firmaSilButton;
    private JTextArea textArea1;
    private JButton firmalarıGösterButton;
    private Admin admin;
    private JLabel firmaListesiLabel;
    private JLabel textArea2;

    public adminSayfasi() {
    }

    public adminSayfasi(Admin admin) {
        this.admin = new Admin("adminUsername", "adminPassword");


        // Swing arayüz öğelerini oluştur
        panel1 = new JPanel();
        textArea1 = new JTextArea(10, 10);
        firmaEkleButton = new JButton("Firma Ekle");
        firmaSilButton = new JButton("Firma Sil");
        firmalarıGösterButton = new JButton("Firmaları Göster");
        textArea2 = new JLabel("HİZMET BEDELİ 1000 TL DİR.");

        firmaListesiLabel = new JLabel("");
        panel1.add(firmaListesiLabel);

        firmalarıGösterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firmalarıGösterButonuTiklandi();
            }
        });


        // Firma Ekle butonuna tıklanınca bir olay dinleyici ekle
        firmaEkleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firmaEkleButonuTiklandi();
            }
        });

        // Firma Sil butonuna tıklanınca bir olay dinleyici ekle
        firmaSilButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firmaSilButonuTiklandi();
            }
        });

        // Firma göster butonuna tıklanınca bir olay dinleyici ekle
        firmalarıGösterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firmalarıGösterButonuTiklandi();
            }
        });
        firmalarıGösterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firmalarıGösterButonuTiklandi();
            }
        });

        // Swing bileşenlerini panoya ekleyin
        panel1.add(new JScrollPane(textArea1));
        panel1.add(firmaEkleButton);
        panel1.add(firmaSilButton);
        panel1.add(firmalarıGösterButton);
        panel1.add(textArea2);


        // Frame'i ayarla
        this.add(panel1);
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    // Firma ekle butonu tıklandığında yapılacak işlemler
    private void firmaEkleButonuTiklandi() {
        // Firma eklemek için gerekli işlemleri yap
        String yeniFirmaAdi = JOptionPane.showInputDialog("Yeni Firma Adı:");
        admin.firmaEkleme(yeniFirmaAdi);

        // Güncellenmiş firma listesini göster
        guncellenmisFirmaListesiniGoster();
    }

    // Firma ekle butonu tıklandığında yapılacak işlemler
    private void firmaSilButonuTiklandi() {
        // Firma silmek için gerekli işlemleri yap
        String silinecekFirmaAdi = JOptionPane.showInputDialog("Silinecek Firma Adı:");
        admin.firmaSilme(silinecekFirmaAdi);

        // Güncellenmiş firma listesini göster
        guncellenmisFirmaListesiniGoster();
    }


    // Güncellenmiş firma listesini göster
    private void guncellenmisFirmaListesiniGoster() {
        textArea1.setText("");
        for (String firma : admin.getFirmalar()) {
            textArea1.append(firma + "\n");
        }
    }


    // firma listesini göster
    private void firmalarıGösterButonuTiklandi() {
        guncellenmisFirmaListesiniGoster();
    }

}