public class Personel extends Person{
    //Aracın personel bilgilerini tutan bir classtır.
    //araçta dört personel var. 2 şoför 2 muavin var

    public String getPersonel1() {
        return personel1;
    }

    public void setPersonel1(String personel1) {
        this.personel1 = personel1;
    }

    String personel1;

    public String getPersonel2() {
        return personel2;
    }

    public void setPersonel2(String personel2) {
        this.personel2 = personel2;
    }

    String personel2;

    public String getHizmetli1() {
        return hizmetli1;
    }

    public void setHizmetli1(String hizmetli1) {
        this.hizmetli1 = hizmetli1;
    }

    String hizmetli1;

    public String getHizmetli2() {
        return hizmetli2;
    }

    public void setHizmetli2(String hizmetli2) {
        this.hizmetli2 = hizmetli2;
    }

    String hizmetli2;

    public Personel(String ad, String Soyad) {
        super(ad, Soyad);
    }
}
