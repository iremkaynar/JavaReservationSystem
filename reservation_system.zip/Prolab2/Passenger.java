public class Passenger extends Person{

    public int getTcNo() {
        return TcNo;
    }

    public void setTcNo(int tcNo) {
        TcNo = tcNo;
    }

    int TcNo;

    public String getDogumTarihi() {
        return dogumTarihi;
    }

    public void setDogumTarihi(String dogumTarihi) {
        this.dogumTarihi = dogumTarihi;
    }

    String dogumTarihi;


    public Passenger(String ad, String Soyad) {
        super(ad, Soyad);
    }
}
