import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;


public class firmaGirisi extends JFrame implements ILoginable {
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JButton kayitolButton;
    private JButton girisButton;
    private JPanel panel1;
    public firmaSayfasi firmaPage;

    private static ArrayList<Company> companyList = Company.getCompanyList();

    public firmaGirisi() {
        panel1 = new JPanel();
        setSize(400, 200);
        add(panel1);
        textField1 = new JTextField(10);
        passwordField1 = new JPasswordField(10);
        girisButton = new JButton("Giriş");
        kayitolButton = new JButton("Kayıt Ol");


        panel1.add(new JLabel("Kullanıcı Adı:"));
        panel1.add(textField1);
        panel1.add(new JLabel("Şifre:"));
        panel1.add(passwordField1);
        panel1.add(girisButton);
        panel1.add(kayitolButton);


        // Enter tuşuna basıldığında şifre alanına odaklanma
        textField1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                passwordField1.requestFocusInWindow();
            }
        });

        girisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        kayitolButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerCompany();
            }
        });

    }

    public JPanel getPanel1() {
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public JTextField getTextField1() {
        return textField1;
    }

    public void setTextField1(JTextField textField1) {
        this.textField1 = textField1;
    }


    public JButton getGirisButton() {
        return girisButton;
    }

    public void setGirisButton(JButton girisButton) {
        this.girisButton = girisButton;
    }

    public JPasswordField getPasswordField1() {
        return passwordField1;
    }

    public void setPasswordField1(JPasswordField passwordField1) {
        this.passwordField1 = passwordField1;
    }

    private void openFirmaSayfasi(Company firma) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (firmaPage == null) {
                    firmaPage = new firmaSayfasi(); // Pass the Company object
                    firmaPage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                }
                firmaPage.setVisible(true);
            }
        });
    }

    private void login() {
        String enteredUsername = textField1.getText();
        String enteredPassword = new String(passwordField1.getPassword());

        // Firma listesinde kullanıcının girdiği bilgileri kontrol et
        for (Company firma : companyList) {
            if (enteredUsername.equals(firma.getUsername()) && enteredPassword.equals(firma.getPassword())) {
                JOptionPane.showMessageDialog(this, firma.getUsername() + " firmasına giriş yaptınız!");
                openFirmaSayfasi(firma);
                return; // İşlemi sonlandır
            }
        }

        // Eğer kullanıcı adı ve şifre listede yoksa hata mesajını göster
        JOptionPane.showMessageDialog(this, "Hatalı kullanıcı adı veya şifre!", "Hata", JOptionPane.ERROR_MESSAGE);
    }


    private void registerCompany() {
        String newUsername = textField1.getText();
        String newPassword = new String(passwordField1.getPassword());


        for (Company firma : Company.getCompanyList()) {
            if (newUsername.equals(firma.getUsername())) {
                JOptionPane.showMessageDialog(this, "Bu kullanıcı adı zaten kullanılmaktadır. Lütfen farklı bir kullanıcı adı seçin.");
                return;
            }
        }

        Company newFirma = new Company(newUsername, newPassword);
        Company.addToCompanyList(newFirma);

        JOptionPane.showMessageDialog(this, newUsername + " firması başarıyla kaydedildi!");

    }

    @Override
    public boolean login(String username, String password) {
        return false;
    }

}
