import java.util.HashMap;
import java.util.Map;

public class Route {
    Map<String, String> rota;
    Map<String, Integer> mesafe;

    public Route() {
        rota = new HashMap<>();

        //1.sefer gidiş dönüş
        rota.put("İstanbul", "Kocaeli");
        rota.put("İstanbul", "Bilecik");
        rota.put("İstanbul", "Eskişehir");
        rota.put("İstanbul", "Ankara");

        rota.put("Kocaeli", "Bilecik");
        rota.put("Kocaeli", "İstanbul");
        rota.put("Kocaeli", "Eskişehir");
        rota.put("Kocaeli", "Ankara");

        rota.put("Bilecik", "Kocaeli");
        rota.put("Bilecik", "İstanbul");
        rota.put("Bilecik", "Eskişehir");
        rota.put("Bilecik", "Ankara");

        rota.put("Eskişehir", "Kocaeli");
        rota.put("Eskişehir", "İstanbul");
        rota.put("Eskişehir", "Bilecik");
        rota.put("Eskişehir", "Ankara");

        rota.put("Ankara", "Kocaeli");
        rota.put("Ankara", "İstanbul");
        rota.put("Ankara", "Bilecik");
        rota.put("Ankara", "Eskişehir");

        //2.sefer gidiş dönüş
        rota.put("İstanbul", "Kocaeli");
        rota.put("İstanbul", "Bilecik");
        rota.put("İstanbul", "Eskişehir");
        rota.put("İstanbul", "Konya");

        rota.put("Kocaeli", "Bilecik");
        rota.put("Kocaeli", "İstanbul");
        rota.put("Kocaeli", "Eskişehir");
        rota.put("Kocaeli", "Konya");

        rota.put("Bilecik", "Kocaeli");
        rota.put("Bilecik", "İstanbul");
        rota.put("Bilecik", "Eskişehir");
        rota.put("Bilecik", "Konya");

        rota.put("Eskişehir", "Kocaeli");
        rota.put("Eskişehir", "İstanbul");
        rota.put("Eskişehir", "Bilecik");
        rota.put("Eskişehir", "Konya");

        rota.put("Konya", "Kocaeli");
        rota.put("Konya", "İstanbul");
        rota.put("Konya", "Bilecik");
        rota.put("Konya", "Eskişehir");

        //3.sefer
        rota.put("İstanbul", "Kocaeli");
        rota.put("İstanbul", "Ankara");

        rota.put("Ankara", "Kocaeli");
        rota.put("Ankara", "İstanbul");

        rota.put("Kocaeli", "İstanbul");
        rota.put("Kocaeli", "Ankara");

        //4.sefer
        rota.put("İstanbul", "Kocaeli");
        rota.put("İstanbul", "Eskişehir");
        rota.put("İstanbul", "Konya");

        rota.put("Kocaeli", "İstanbul");
        rota.put("Kocaeli", "Eskişehir");
        rota.put("Kocaeli", "Konya");

        rota.put("Eskişehir", "Kocaeli");
        rota.put("Eskişehir", "İstanbul");
        rota.put("Eskişehir", "Konya");

        rota.put("Konya", "Kocaeli");
        rota.put("Konya", "İstanbul");
        rota.put("Konya", "Eskişehir");

        //5.sefer
        rota.put("İstanbul", "Konya");
        rota.put("Konya", "İstanbul");

        //6.sefer
        rota.put("İstanbul", "Ankara");
        rota.put("Ankara", "İstanbul");


        mesafe = new HashMap<>();
        //sefer 1 demiryolu
        mesafe.put("İstanbul-Kocaeli", 75);
        mesafe.put("İstanbul-Bilecik", 225);
        mesafe.put("İstanbul-Eskişehir", 300);
        mesafe.put("İstanbul-Ankara", 375);

        mesafe.put("Kocaeli-Bilecik", 75);
        mesafe.put("Kocaeli-İstanbul", 75);
        mesafe.put("Kocaeli-Eskişehir", 150);
        mesafe.put("Kocaeli-Ankara", 300);

        mesafe.put("Bilecik-Kocaeli", 75);
        mesafe.put("Bilecik-İstanbul", 225);
        mesafe.put("Bilecik-Eskişehir", 75);
        mesafe.put("Bilecik-Ankara", 225);

        mesafe.put("Eskişehir-Kocaeli", 150);
        mesafe.put("Eskişehir-İstanbul", 300);
        mesafe.put("Eskişehir-Bilecik", 75);
        mesafe.put("Eskişehir-Ankara", 150);

        mesafe.put("Ankara-Kocaeli", 300);
        mesafe.put("Ankara-İstanbul", 375);
        mesafe.put("Ankara-Bilecik", 225);
        mesafe.put("Ankara-Eskişehir", 150);

        //sefer 2 demiryolu

        mesafe.put("İstanbul-Konya", 450);


        mesafe.put("Kocaeli-Konya", 350);


        mesafe.put("Bilecik-Konya", 300);


        mesafe.put("Eskişehir-Konya", 225);

        mesafe.put("Konya-Kocaeli", 350);
        mesafe.put("Konya-İstanbul", 450);
        mesafe.put("Konya-Bilecik", 300);
        mesafe.put("Konya-Eskişehir", 225);

        //sefer 3 karayolu
        mesafe.put("İstanbul-Kocaeli", 100);
        mesafe.put("İstanbul-Ankara", 500);


        mesafe.put("Kocaeli-İstanbul", 100);
        mesafe.put("Kocaeli-Ankara", 400);

        mesafe.put("Ankara-Kocaeli", 400);
        mesafe.put("Ankara-İstanbul", 500);

        //sefer 4 karayolu
        mesafe.put("İstanbul-Eskişehir", 300);
        mesafe.put("İstanbul-Konya", 600);

        mesafe.put("Kocaeli-Eskişehir", 200);
        mesafe.put("Kocaeli-Konya", 500);

        mesafe.put("Eskişehir-Kocaeli", 200);
        mesafe.put("Eskişehir-İstanbul", 300);
        mesafe.put("Eskişehir-Konya", 300);

        mesafe.put("Konya-Kocaeli", 500);
        mesafe.put("Konya-İstanbul", 600);
        mesafe.put("Konya-Eskişehir", 300);

        //sefer 5 havayolu
        mesafe.put("Konya-İstanbul", 300);
        mesafe.put("İstanbul-Konya", 300);

        //sefer 6 havayolu
        mesafe.put("Ankara-İstanbul", 250);
        mesafe.put("İstanbul-Ankara", 250);
    }

    public boolean yolculukYapilabilirMi(String kalkisNoktasi, String varisNoktasi) {
        return rota.containsKey(kalkisNoktasi) && rota.containsValue(varisNoktasi);
    }

    public void mesafeleriYazdir() {
        for (Map.Entry<String, Integer> entry : mesafe.entrySet()) {
            String sehirler = entry.getKey();
            int uzaklik = entry.getValue();
            System.out.println(sehirler + " mesafesi: " + uzaklik + " km");
        }

    }

}