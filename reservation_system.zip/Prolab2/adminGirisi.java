import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class adminGirisi extends JFrame implements ILoginable {
    private JPanel panel1;
    private JTextField textField1;
    private JButton girisButton;
    private JPasswordField passwordField1;
    public adminSayfasi adminPage;

    private static final String ADMIN_USERNAME = "admin";
    private static final String ADMIN_PASSWORD = "admin123";

    public adminGirisi() {
        add(panel1);
        setSize(400, 200);
        setTitle("Admin Girişi");

        // Enter tuşuna basıldığında şifre alanına odaklanma
        textField1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                passwordField1.requestFocusInWindow();
            }
        });


        // Giriş butonuna Enter tuşu ile tıklanma özelliği ekleme
        girisButton.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    login();
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        });


        girisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login(); // Giriş butonuna tıklandığında login metodunu çağır
            }
        });
    }

    private void openAdminSayfasi(Admin admin) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (adminPage == null) {
                    adminPage = new adminSayfasi(admin);
                    adminPage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                }
                adminPage.setVisible(true);
            }
        });
    }

    private void login() {
        String username = textField1.getText();
        String password = new String(passwordField1.getPassword());

        // Kullanıcı adı ve şifreyi kontrol etme
        if (username.equals(ADMIN_USERNAME) && password.equals(ADMIN_PASSWORD)) {
            JOptionPane.showMessageDialog(this, "Giriş başarılı!");

            // adminSayfasi için Admin object i oluşturma
            Admin admin = new Admin();
            openAdminSayfasi(admin); // başarılı girişten sonra adminSayfasi açma
        } else {
            JOptionPane.showMessageDialog(this, "Hatalı kullanıcı adı veya şifre!", "Hata", JOptionPane.ERROR_MESSAGE);
        }
    }

    public JPanel getPanel1() {
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }

    public JTextField getTextField1() {
        return textField1;
    }

    public void setTextField1(JTextField textField1) {
        this.textField1 = textField1;
    }


    public JButton getGirisButton() {
        return girisButton;
    }

    public void setGirisButton(JButton girisButton) {
        this.girisButton = girisButton;
    }

    public JPasswordField getPasswordField1() {
        return passwordField1;
    }

    public void setPasswordField1(JPasswordField passwordField1) {
        this.passwordField1 = passwordField1;
    }

    @Override
    public boolean login(String username, String password) {
        return false;
    }

}
