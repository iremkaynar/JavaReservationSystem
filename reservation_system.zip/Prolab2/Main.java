import javax.swing.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        // Admin sınıfından bir nesne oluştur
        Admin admin = new Admin("kullanici_adi", "parola");

        //A firmasi araclari
        Bus bus1CompanyA = new Bus(1, "Benzin", 20, "A", 3, 10);
        Bus bus2CompanyA = new Bus(2, "Benzin", 15, "A", 3, 10);

        //B firmasi araclari
        Bus bus1CompanyB = new Bus(1, "Motorin", 15, "B", 3, 5);
        Bus bus2CompanyB = new Bus(2, "Motorin", 20, "B", 4, 5);

        //C firmasi araclari
        Bus bus1CompanyC = new Bus(1, "Motorin", 20, "C", 4, 6);
        Plane plane1CompanyC = new Plane(1, "Gaz", 30, "C", 5, 25);
        Plane plane2CompanyC = new Plane(2, "Gaz", 30, "C", 5, 25);

        //D firmasi araclari
        Train train1CompanyD = new Train(1, "Elektrik", 25, "D", 1, 3);
        Train train2CompanyD = new Train(2, "Elektrik", 25, "D", 2, 3);
        Train train3CompanyD = new Train(3, "Elektrik", 25, "D", 2, 3);

        //F firmasi araclari
        Plane plane1CompanyF = new Plane(1, "Gaz", 30, "F", 6, 20);
        Plane plane2CompanyF = new Plane(2, "Gaz", 30, "F", 6, 20);

        // Print information about the bus
        System.out.println("Bus Information:");
        System.out.println("Vehicle ID: " + bus1CompanyA.vehicleId);
        System.out.println("Fuel Type: " + bus1CompanyA.fuelType);
        System.out.println("Capacity of passenger: " + bus1CompanyA.capacity);
        System.out.println("Company Name: " + bus1CompanyA.companyName);
        System.out.println("Trip no: " + bus1CompanyA.tripNo);
        System.out.println("Fuel mileage fee: " + bus1CompanyA.fuelMileageFee);

        System.out.println("Seat Status for Plane 1:");
        bus1CompanyA.displaySeatStatus();
        System.out.println();
        bus2CompanyA.displaySeatStatus();
        System.out.println();
        bus1CompanyB.displaySeatStatus();
        System.out.println();
        bus2CompanyB.displaySeatStatus();
        System.out.println();
        bus1CompanyC.displaySeatStatus();
        System.out.println();
        plane1CompanyC.displaySeatStatus();
        System.out.println();
        plane2CompanyC.displaySeatStatus();
        System.out.println();
        train1CompanyD.displaySeatStatus();
        System.out.println();
        train2CompanyD.displaySeatStatus();
        System.out.println();
        train3CompanyD.displaySeatStatus();
        System.out.println();
        plane1CompanyF.displaySeatStatus();
        System.out.println();
        plane2CompanyF.displaySeatStatus();

        //swing panel açma
        girisPaneli f = new girisPaneli();
        f.setVisible(true);


        adminSayfasi adminPage = new adminSayfasi(admin);


        ArrayList<Sefer> sefer1Listesi = new ArrayList<>();
        // Sefer1_d nesnelerini ArrayList'e ekleme
        sefer1Listesi.add(new Sefer());
        // ArrayList'teki her bir Sefer1_d nesnesinin sefer1 dizisini yazdırma
        for (Sefer sefer1_d : sefer1Listesi) {
            System.out.println(java.util.Arrays.toString(sefer1_d.sefer1));
        }

        Route seferGuzergahi = new Route();


        // Yolculuk için kalkış ve varış noktaları
        String kalkisNoktasi = "Bilecik";
        String varisNoktasi = "İstanbul";


        if (seferGuzergahi.yolculukYapilabilirMi(kalkisNoktasi, varisNoktasi)) {
            System.out.println(kalkisNoktasi + " şehrinden " + varisNoktasi + " şehrine yolculuk yapılabilir.");
        } else {
            System.out.println("Belirtilen rotada doğrudan yolculuk mümkün değil.");
        }

        Route rota = new Route();

        // Route sınıfı içindeki mesafeleri yazdırma
        rota.mesafeleriYazdir();

        bus1CompanyA.calculateFuelCost();
        {
            int yakitGideri = bus1CompanyA.fuelMileageFee * 100;
            System.out.println("A firmasının Otobüs 1 için yakıt gideri: " + yakitGideri);
        }
        bus1CompanyA.calculateFuelCost();


        Trip sefer = new Trip();
        firmaSayfasi firmaPage = new firmaSayfasi();
        firmaPage.showCompanyVehiclesInfo();

        Company company = new Company("myCompany", "myPassword");

        // firmaKayitEtme metodu kullanılarak kullanıcı adı ve şifreyi yazdır
        company.firmaKayitEtme();

        // Şirket listesinin bilgilerini yazdır
        ArrayList<Company> companyList = Company.getCompanyList();
        for (Company firma : companyList) {
            System.out.println("Kullanıcı Adı: " + firma.getUsername() + ", Şifre: " + firma.getPassword());
        }

    }
}