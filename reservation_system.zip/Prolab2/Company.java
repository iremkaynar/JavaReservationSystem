import java.util.ArrayList;
import java.util.List;

public class Company extends User implements IProfitable {

    public List<String> firmaSifreleri;

    public Company(String username, String password) {
        super(username, password);
        this.firmaSifreleri = new ArrayList<>();
    }

    public Company getaFirma() {
        return aFirma;
    }

    public void setaFirma(Company aFirma) {
        this.aFirma = aFirma;
    }

    public Company getbFirma() {
        return bFirma;
    }

    public void setbFirma(Company bFirma) {
        this.bFirma = bFirma;
    }

    public Company getcFirma() {
        return cFirma;
    }

    public void setcFirma(Company cFirma) {
        this.cFirma = cFirma;
    }

    public Company getdFirma() {
        return dFirma;
    }

    public void setdFirma(Company dFirma) {
        this.dFirma = dFirma;
    }

    public Company getfFirma() {
        return fFirma;
    }

    public void setfFirma(Company fFirma) {
        this.fFirma = fFirma;
    }


    @Override
    public void karHesabi() {
        //Gunluk kar hesabı yapılabilir.
        //yolcu ucretleri, hizmet.
        //bedeli, personel maliyeti ve yakıt maliyeti dikkate alınarak hesaplanmalıdır.
    }

    @Override
    public void ekleme() {

    }

    @Override
    public void cikarma() {

    }

    public Company() {

        super();
    }

    public void firmaKayitEtme() {
        String firmaUsername = getUsername();
        String firmaPassword = getPassword();

    }

    private static Company aFirma = new Company("afirma", "afirma123");
    private static Company bFirma = new Company("bfirma", "bfirma123");
    private static Company cFirma = new Company("cfirma", "cfirma123");
    private static Company dFirma = new Company("dfirma", "dfirma123");
    private static Company fFirma = new Company("ffirma", "ffirma123");

    private static ArrayList<Company> companyList = new ArrayList<>();

    static {
        companyList.add(aFirma);
        companyList.add(bFirma);
        companyList.add(cFirma);
        companyList.add(dFirma);
        companyList.add(fFirma);
    }

    public static ArrayList<Company> getCompanyList() {
        return companyList;
    }

    public static void addToCompanyList(Company newFirma) {
        companyList.add(newFirma);
    }

    public void ekleme(String yeniAd) {
    }

    public void cikarma(String silinecekAraçAdi) {
    }
}