public interface IReservable {
    void showAvailableSeats(); // Koltukların mevcut durumunu gösteren metot
    void selectSeat(int seatNumber); // Belirli bir koltuğun rezerve edilmesini sağlayan metot
}