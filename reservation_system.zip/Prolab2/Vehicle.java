import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public abstract class Vehicle {
    public int getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(int vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getTripNo() {
        return tripNo;
    }

    public void setTripNo(int tripNo) {
        this.tripNo = tripNo;
    }

    public int getFuelMileageFee() {
        return fuelMileageFee;
    }

    public void setFuelMileageFee(int fuelMileageFee) {
        this.fuelMileageFee = fuelMileageFee;
    }

    public Map<Integer, Boolean> getSeatStatus() {
        return seatStatus;
    }

    public void setSeatStatus(Map<Integer, Boolean> seatStatus) {
        this.seatStatus = seatStatus;
    }

    int vehicleId;
    String fuelType;
    int capacity;
    String companyName;
    int tripNo;
    int fuelMileageFee;

    public void calculateFuelCost() {
        
    }



    protected Map<Integer, Boolean> seatStatus;


    public Vehicle() {
        seatStatus = new HashMap<>();
    }


    public void initializeSeatStatus(int capacity) {

        Random random = new Random();
        for (int i = 1; i <= capacity; i++) {
            boolean isReserved = random.nextBoolean();
            seatStatus.put(i, isReserved);
        }
    }


    public void displaySeatStatus() {
        for (Map.Entry<Integer, Boolean> entry : seatStatus.entrySet()) {
            int seatNumber = entry.getKey();
            boolean isReserved = entry.getValue();
            String status = isReserved ? "Dolu" : "Boş";
            System.out.println("Koltuk " + seatNumber + ": " + status);
        }
    }

    public Vehicle(int vehicleId, String fuelType, int capacity, String companyName, int tripNo, int fuelMileageFee) {
        this.vehicleId = vehicleId;
        this.fuelType = fuelType;
        this.capacity = capacity;
        this.companyName = companyName;
        this.tripNo = tripNo;
        this.fuelMileageFee = fuelMileageFee;
    }
}