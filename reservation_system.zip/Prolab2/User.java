public abstract class User implements ILoginable{

    public User() {

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    String username;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    String password;


// hizmet bedeli ya da gğnlğk kar hesaplama
    public abstract void karHesabi();
// firma veya sefer ekleme
    public abstract void ekleme();
// firma veya sefer çıkarma silme
    public abstract void cikarma();

    public User(String username,String password ){

        this.username= username;
        this.password= password;

    }

    @Override
    public boolean login(String username, String password) {
        // Kullanıcının giriş yapma mantığı burada implement edilir
        return this.username.equals(username) && this.password.equals(password);
    }
}
