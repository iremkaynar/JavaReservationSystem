import java.util.*;
class Sefer {
    public String[] getSefer1() {
        return sefer1;
    }

    public void setSefer1(String[] sefer1) {
        this.sefer1 = sefer1;
    }

    String[] sefer1;


    // Constructor
    public Sefer() {
        // sefer1 dizisi
        sefer1 = new String[]{"İstanbul", "Kocaeli", "Bilecik", "Eskişehir", "Ankara", "Eskişehir", "Bilecik", "Kocaeli", "İstanbul"};

        String[] sefer2 = new String[]{"İstanbul", "Kocaeli", "Bilecik", "Eskişehir", "Konya", "Eskişehir", "Bilecik", "Kocaeli", "İstanbul"};

        String[] sefer3 = new String[]{"İstanbul", "Kocaeli", "Ankara", "Kocaeli", "İstanbul", "Kocaeli", "Ankara", "Kocaeli", "İstanbul"};

        String[] sefer4 = new String[]{"İstanbul", "Kocaeli", "Eskişehir", "Konya", "Eskişehir", "Kocaeli", "İstanbul"};

        String[] sefer5 = new String[]{"İstanbul", "Konya", "İstanbul"};

        String[] sefer6 = new String[]{"İstanbul", "Ankara", "İstanbul"};
    }
}

public class Trip{
    public static Map<String, Integer> getFiyatlar() {
        return fiyatlar;
    }

    public static void setFiyatlar(Map<String, Integer> fiyatlar) {
        Trip.fiyatlar = fiyatlar;
    }

    public String getArac() {
        return arac;
    }

    public void setArac(String arac) {
        this.arac = arac;
    }

    public int getZaman() {
        return zaman;
    }

    public void setZaman(int zaman) {
        this.zaman = zaman;
    }

    public String getGuzergah() {
        return guzergah;
    }

    public void setGuzergah(String guzergah) {
        this.guzergah = guzergah;
    }

    public int getFiyat() {
        return fiyat;
    }

    public void setFiyat(int fiyat) {
        this.fiyat = fiyat;
    }

    public Bus getBus1CompanyA() {
        return bus1CompanyA;
    }

    public void setBus1CompanyA(Bus bus1CompanyA) {
        this.bus1CompanyA = bus1CompanyA;
    }

    public Bus getBus2CompanyA() {
        return bus2CompanyA;
    }

    public void setBus2CompanyA(Bus bus2CompanyA) {
        this.bus2CompanyA = bus2CompanyA;
    }

    public Bus getBus1CompanyB() {
        return bus1CompanyB;
    }

    public void setBus1CompanyB(Bus bus1CompanyB) {
        this.bus1CompanyB = bus1CompanyB;
    }

    public Bus getBus2CompanyB() {
        return bus2CompanyB;
    }

    public void setBus2CompanyB(Bus bus2CompanyB) {
        this.bus2CompanyB = bus2CompanyB;
    }

    public Bus getBus1CompanyC() {
        return bus1CompanyC;
    }

    public void setBus1CompanyC(Bus bus1CompanyC) {
        this.bus1CompanyC = bus1CompanyC;
    }

    public Plane getPlane1CompanyC() {
        return plane1CompanyC;
    }

    public void setPlane1CompanyC(Plane plane1CompanyC) {
        this.plane1CompanyC = plane1CompanyC;
    }

    public Plane getPlane2CompanyC() {
        return plane2CompanyC;
    }

    public void setPlane2CompanyC(Plane plane2CompanyC) {
        this.plane2CompanyC = plane2CompanyC;
    }

    public Train getTrain1CompanyD() {
        return train1CompanyD;
    }

    public void setTrain1CompanyD(Train train1CompanyD) {
        this.train1CompanyD = train1CompanyD;
    }

    public Train getTrain2CompanyD() {
        return train2CompanyD;
    }

    public void setTrain2CompanyD(Train train2CompanyD) {
        this.train2CompanyD = train2CompanyD;
    }

    public Train getTrain3CompanyD() {
        return train3CompanyD;
    }

    public void setTrain3CompanyD(Train train3CompanyD) {
        this.train3CompanyD = train3CompanyD;
    }

    public Plane getPlane1CompanyF() {
        return plane1CompanyF;
    }

    public void setPlane1CompanyF(Plane plane1CompanyF) {
        this.plane1CompanyF = plane1CompanyF;
    }

    public Plane getPlane2CompanyF() {
        return plane2CompanyF;
    }

    public void setPlane2CompanyF(Plane plane2CompanyF) {
        this.plane2CompanyF = plane2CompanyF;
    }

    static Map<String, Integer> fiyatlar;
    String arac;
    int zaman;
    String guzergah;
    int fiyat;


    //A firmasi araclari
    Bus bus1CompanyA = new Bus(1, "Benzin", 20, "A", 3, 10);
    Bus bus2CompanyA = new Bus(2, "Benzin", 15, "A", 3, 10);

    //B firmasi araclari
    Bus bus1CompanyB = new Bus(1, "Motorin", 15, "B", 3, 5);
    Bus bus2CompanyB = new Bus(2, "Motorin", 20, "B", 4, 5);

    //C firmasi araclari
    Bus bus1CompanyC = new Bus(1, "Motorin", 20, "C", 4, 6);
    Plane plane1CompanyC = new Plane(1, "Gaz", 30, "C", 5, 25);
    Plane plane2CompanyC = new Plane(2, "Gaz", 30, "C", 5, 25);

    //D firmasi araclari
    Train train1CompanyD = new Train(1, "Elektrik", 25, "D", 1, 3);
    Train train2CompanyD = new Train(2, "Elektrik", 25, "D", 2, 3);
    Train train3CompanyD = new Train(3, "Elektrik", 25, "D", 2, 3);

    //F firmasi araclari
    Plane plane1CompanyF = new Plane(1, "Gaz", 30, "F", 6, 20);
    Plane plane2CompanyF = new Plane(2, "Gaz", 30, "F", 6, 20);




    public Trip() {
        fiyatlar = new HashMap<>();

        String sefer_1 = train1CompanyD.toString(); // sefer_1 in aracı tren1
        String sefer_2_A = train2CompanyD.toString();
        String sefer_2_B = train3CompanyD.toString();
        String sefer_3_A = bus1CompanyA.toString();
        String sefer_3_B = bus2CompanyA.toString();
        String sefer_3_C = bus1CompanyB.toString();
        String sefer_4_A = bus2CompanyB.toString();
        String sefer_4_B = bus1CompanyC.toString();
        String sefer_5_A = plane1CompanyC.toString();
        String sefer_5_B = plane2CompanyC.toString();
        String sefer_6_A = plane1CompanyF.toString();
        String sefer_6_B = plane2CompanyF.toString();



        //sefer 1 demiryolu
        fiyatlar.put("İstanbul-Kocaeli", 50);
        fiyatlar.put("İstanbul-Bilecik", 150);
        fiyatlar.put("İstanbul-Eskişehir", 200);
        fiyatlar.put("İstanbul-Ankara", 250);

        fiyatlar.put("Kocaeli-Bilecik", 50);
        fiyatlar.put("Kocaeli-İstanbul", 50);
        fiyatlar.put("Kocaeli-Eskişehir", 100);
        fiyatlar.put("Kocaeli-Ankara", 200);

        fiyatlar.put("Bilecik-Kocaeli", 50);
        fiyatlar.put("Bilecik-İstanbul", 150);
        fiyatlar.put("Bilecik-Eskişehir", 50);
        fiyatlar.put("Bilecik-Ankara", 150);

        fiyatlar.put("Eskişehir-Kocaeli", 100);
        fiyatlar.put("Eskişehir-İstanbul", 200);
        fiyatlar.put("Eskişehir-Bilecik", 50);
        fiyatlar.put("Eskişehir-Ankara", 100);

        fiyatlar.put("Ankara-Kocaeli", 200);
        fiyatlar.put("Ankara-İstanbul", 250);
        fiyatlar.put("Ankara-Bilecik", 150);
        fiyatlar.put("Ankara-Eskişehir", 100);

        //sefer 2 demiryolu

        fiyatlar.put("İstanbul-Konya", 300);


        fiyatlar.put("Kocaeli-Konya", 250);


        fiyatlar.put("Bilecik-Konya", 200);


        fiyatlar.put("Eskişehir-Konya", 150);

        fiyatlar.put("Konya-Kocaeli", 250);
        fiyatlar.put("Konya-İstanbul", 300);
        fiyatlar.put("Konya-Bilecik", 200);
        fiyatlar.put("Konya-Eskişehir", 150);

        //sefer 3 karayolu
        fiyatlar.put("İstanbul-Kocaeli", 50);
        fiyatlar.put("İstanbul-Ankara", 300);


        fiyatlar.put("Kocaeli-İstanbul", 50);
        fiyatlar.put("Kocaeli-Ankara", 400);

        fiyatlar.put("Ankara-Kocaeli", 400);
        fiyatlar.put("Ankara-İstanbul", 300);

        //sefer 4 karayolu
        fiyatlar.put("İstanbul-Eskişehir", 150);
        fiyatlar.put("İstanbul-Konya", 300);

        fiyatlar.put("Kocaeli-Eskişehir", 100);
        fiyatlar.put("Kocaeli-Konya", 250);

        fiyatlar.put("Eskişehir-Kocaeli", 100);
        fiyatlar.put("Eskişehir-İstanbul", 150);
        fiyatlar.put("Eskişehir-Konya", 150);

        fiyatlar.put("Konya-Kocaeli", 250);
        fiyatlar.put("Konya-İstanbul", 300);
        fiyatlar.put("Konya-Eskişehir", 150);

        //sefer 5 havayolu
        fiyatlar.put("Konya-İstanbul", 1200);
        fiyatlar.put("İstanbul-Konya", 1200);

        //sefer 6 havayolu
        fiyatlar.put("Ankara-İstanbul", 1000);
        fiyatlar.put("İstanbul-Ankara", 1000);

    }
}